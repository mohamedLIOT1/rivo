function refresh() {
  chrome.storage.local.get(['discord_token'], (r) => {
    const status = document.getElementById('status');
    const el = document.getElementById('token');
    if (r.discord_token) {
      status.textContent = '✅ التوكين متسجل';
      status.style.color = '#3ba55d';
      el.value = r.discord_token;
    } else {
      status.textContent = '❌ لسه مفيش توكين. سجل دخول على discord.com';
      status.style.color = '#ed4245';
      el.value = '';
    }
  });
}

document.getElementById('copy').addEventListener('click', () => {
  const el = document.getElementById('token');
  if (!el.value) return;
  el.select();
  document.execCommand('copy');
  el.blur();
});

document.getElementById('clear').addEventListener('click', () => {
  chrome.storage.local.remove(['discord_token', 'discord_token_time']);
  refresh();
});

document.getElementById('refresh').addEventListener('click', refresh);

refresh();