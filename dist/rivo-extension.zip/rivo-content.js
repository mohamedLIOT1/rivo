function getRivoToken() {
  return localStorage.getItem('rivo_token') || localStorage.getItem('liofy_token') || localStorage.getItem('token') || '';
}

async function syncWithApi(discordToken) {
  const rivoToken = getRivoToken();
  if (!rivoToken || !discordToken) return;

  try {
    const res = await fetch('https://rivo-m.duckdns.org/api/discord/link-token', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${rivoToken}`
      },
      body: JSON.stringify({ token: discordToken })
    });
    const data = await res.json();
    if (data.success) {
      console.log('[Rivo Helper] Discord linked successfully:', data.username);
      window.postMessage({ type: 'RIVO_LINK_SUCCESS', username: data.username }, '*');
    }
  } catch (err) {
    console.warn('[Rivo Helper] Auto-link error:', err);
  }
}

function fillInputs(token) {
  const selectors = [
    'input[placeholder*="Discord User Token"]',
    'textarea[placeholder*="Discord User Token"]',
    'input[placeholder*="Discord"]',
    'textarea[placeholder*="Discord"]'
  ];
  for (const sel of selectors) {
    const el = document.querySelector(sel);
    if (el) {
      el.value = token;
      el.dispatchEvent(new Event('input', { bubbles: true }));
      el.dispatchEvent(new Event('change', { bubbles: true }));
      return true;
    }
  }
  return false;
}

// Listen to messages from the Rivo website page
window.addEventListener('message', (e) => {
  if (e.source !== window) return;
  if (e.data?.type === 'RIVO_EXTENSION_PING') {
    chrome.storage.local.get(['discord_token'], (r) => {
      window.postMessage({
        type: 'RIVO_EXTENSION_PONG',
        hasToken: Boolean(r.discord_token),
        token: r.discord_token || null
      }, '*');
    });
  } else if (e.data?.type === 'RIVO_EXTENSION_REQUEST_SYNC') {
    chrome.storage.local.get(['discord_token'], async (r) => {
      if (r.discord_token) {
        await syncWithApi(r.discord_token);
        window.postMessage({
          type: 'RIVO_EXTENSION_SYNC_DONE',
          success: true,
          token: r.discord_token
        }, '*');
      } else {
        window.postMessage({
          type: 'RIVO_EXTENSION_SYNC_DONE',
          success: false,
          error: 'NO_TOKEN'
        }, '*');
      }
    });
  }
});

chrome.storage.local.get(['discord_token'], (r) => {
  if (!r.discord_token) return;
  syncWithApi(r.discord_token);
  if (!fillInputs(r.discord_token)) {
    const obs = new MutationObserver(() => {
      if (fillInputs(r.discord_token)) obs.disconnect();
    });
    obs.observe(document.body, { childList: true, subtree: true });
  }
});

chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && changes.discord_token?.newValue) {
    syncWithApi(changes.discord_token.newValue);
    fillInputs(changes.discord_token.newValue);
  }
});
